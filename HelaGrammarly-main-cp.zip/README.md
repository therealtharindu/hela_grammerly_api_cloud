# HelaGrammarly

Sinhala Language Software is a grammar and spell checking software, used to check the errors in Sinhala word sentences.
